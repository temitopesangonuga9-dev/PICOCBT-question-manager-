<?php
/**
 * PICOCBT Question Manager - OpenAI Configuration
 * -----------------------------------------------------
 * LOCAL XAMPP: paste your key directly into the fallback value below.
 * HOSTED (Railway/Render/etc.): set OPENAI_API_KEY as an environment
 * variable in your host's dashboard instead - keeps it out of your code/GitHub repo.
 *
 * Get a key at: https://platform.openai.com/api-keys
 * NEVER commit a real key to a public GitHub repo.
 */

define('OPENAI_API_KEY', getenv('OPENAI_API_KEY') ?: 'sk-REPLACE-WITH-YOUR-OPENAI-API-KEY');
define('OPENAI_MODEL', getenv('OPENAI_MODEL') ?: 'gpt-4o-mini'); // good balance of cost/quality for question generation

/**
 * Calls the OpenAI Chat Completions API and returns the raw text reply.
 *
 * @param string $systemPrompt Instructions describing the assistant's role/output format
 * @param string $userPrompt   The actual task/content
 * @param float  $temperature  Creativity level (0 = strict/deterministic, 1 = creative)
 * @return array ['success' => bool, 'content' => string|null, 'error' => string|null]
 */
function callOpenAI(string $systemPrompt, string $userPrompt, float $temperature = 0.4): array
{
    if (OPENAI_API_KEY === 'sk-REPLACE-WITH-YOUR-OPENAI-API-KEY' || trim(OPENAI_API_KEY) === '') {
        return ['success' => false, 'content' => null, 'error' => 'OpenAI API key is not configured. Edit config/openai.php.'];
    }

    $payload = [
        'model'       => OPENAI_MODEL,
        'messages'    => [
            ['role' => 'system', 'content' => $systemPrompt],
            ['role' => 'user',   'content' => $userPrompt],
        ],
        'temperature' => $temperature,
        // Ask the API to guarantee valid JSON back - much easier to parse reliably.
        'response_format' => ['type' => 'json_object'],
    ];

    $ch = curl_init('https://api.openai.com/v1/chat/completions');
    curl_setopt_array($ch, [
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_POST           => true,
        CURLOPT_HTTPHEADER     => [
            'Content-Type: application/json',
            'Authorization: Bearer ' . OPENAI_API_KEY,
        ],
        CURLOPT_POSTFIELDS     => json_encode($payload),
        CURLOPT_TIMEOUT        => 90,
    ]);

    $response = curl_exec($ch);
    $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    $curlErr  = curl_error($ch);
    curl_close($ch);

    if ($curlErr) {
        return ['success' => false, 'content' => null, 'error' => 'cURL error: ' . $curlErr];
    }

    $decoded = json_decode($response, true);

    if ($httpCode !== 200) {
        $msg = $decoded['error']['message'] ?? ('HTTP ' . $httpCode);
        return ['success' => false, 'content' => null, 'error' => 'OpenAI API error: ' . $msg];
    }

    $content = $decoded['choices'][0]['message']['content'] ?? null;

    if ($content === null) {
        return ['success' => false, 'content' => null, 'error' => 'Unexpected OpenAI response format.'];
    }

    return ['success' => true, 'content' => $content, 'error' => null];
}
