<?php
/**
 * PICOCBT Question Manager - Database Configuration
 * -----------------------------------------------------
 * Works two ways:
 * 1. LOCAL XAMPP: edit the fallback values below directly.
 * 2. HOSTED (Railway/Render/etc.): set these as environment variables
 *    in your host's dashboard - DB_HOST, DB_NAME, DB_USER, DB_PASS, DB_PORT -
 *    and this file will pick them up automatically, no code changes needed.
 */

define('DB_HOST', getenv('DB_HOST') ?: 'localhost');
define('DB_NAME', getenv('DB_NAME') ?: 'picocbt');   // <-- change to your actual PICOCBT database name
define('DB_USER', getenv('DB_USER') ?: 'root');      // <-- your MySQL username
define('DB_PASS', getenv('DB_PASS') ?: '');          // <-- your MySQL password (blank by default on XAMPP)
define('DB_PORT', getenv('DB_PORT') ?: '3306');

try {
    $pdo = new PDO(
        "mysql:host=" . DB_HOST . ";port=" . DB_PORT . ";dbname=" . DB_NAME . ";charset=utf8mb4",
        DB_USER,
        DB_PASS,
        [
            PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
            PDO::ATTR_EMULATE_PREPARES   => false,
        ]
    );
} catch (PDOException $e) {
    die("Database connection failed: " . htmlspecialchars($e->getMessage()));
}
