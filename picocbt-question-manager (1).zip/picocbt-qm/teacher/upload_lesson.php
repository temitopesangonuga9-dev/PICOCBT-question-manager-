<?php
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/functions.php';
requireTeacher();

$pageTitle = 'Lesson Note to MCQ';
$assetPath = '../assets/';
require_once __DIR__ . '/../includes/header.php';
?>

<div class="card">
    <div class="card-header">📄 Convert Lesson Note to Questions</div>
    <div class="card-body">
        <div class="grid-2">
            <div>
                <label>Subject</label>
                <select id="subject" required>
                    <option value="">-- Select --</option>
                    <?php foreach (subjectList() as $s): ?>
                        <option value="<?= e($s) ?>" <?= (($_SESSION['subject'] ?? '') === $s) ? 'selected' : '' ?>><?= e($s) ?></option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div>
                <label>Class Level</label>
                <select id="classLevel">
                    <option value="JSS1">JSS1</option>
                    <option value="JSS2">JSS2</option>
                    <option value="JSS3">JSS3</option>
                    <option value="SS1">SS1</option>
                    <option value="SS2">SS2</option>
                    <option value="SS3">SS3</option>
                </select>
            </div>
        </div>

        <label>Upload Lesson Note (.txt, .docx, .pdf)</label>
        <input type="file" id="lessonFile" accept=".txt,.docx,.pdf">

        <label>...or paste the lesson note text directly</label>
        <textarea id="pastedText" rows="6" placeholder="Paste lesson note content here"></textarea>

        <button class="btn" id="extractBtn" onclick="extractText()" style="margin-top:14px;">Extract Text</button>
        <div id="extractError"></div>

        <div id="extractedWrap" style="display:none; margin-top:16px;">
            <label>Extracted Text (you can edit before generating questions)</label>
            <textarea id="extractedText" rows="10"></textarea>

            <div class="grid-2">
                <div>
                    <label>Question Type</label>
                    <select id="questionType">
                        <option value="mcq">Multiple Choice (MCQ)</option>
                        <option value="theory">Theory</option>
                    </select>
                </div>
                <div>
                    <label>Difficulty</label>
                    <select id="difficulty">
                        <option value="easy">Easy</option>
                        <option value="medium" selected>Medium</option>
                        <option value="hard">Hard</option>
                    </select>
                </div>
            </div>
            <label>Number of Questions</label>
            <input type="number" id="count" value="10" min="1" max="20">

            <button class="btn btn-block" id="generateBtn" onclick="generateFromLesson()">Generate Questions from this Note</button>
            <div id="genError"></div>
        </div>
    </div>
</div>

<div id="resultsWrap" style="display:none;">
    <div class="card">
        <div class="card-header">Review &amp; Edit Generated Questions</div>
        <div class="card-body">
            <p>Edit anything below before submitting. Uncheck the box to exclude a question you don't want to keep.</p>
            <div id="questionsPreview"></div>
            <button class="btn btn-block" onclick="saveQuestions()">Submit Selected Questions for Review</button>
            <div id="saveMsg"></div>
        </div>
    </div>
</div>

<script>
const csrfToken = "<?= e(csrfToken()) ?>";
let currentMeta = {};

async function extractText() {
    const btn = document.getElementById('extractBtn');
    const errorBox = document.getElementById('extractError');
    errorBox.innerHTML = '';

    const fileInput = document.getElementById('lessonFile');
    const pasted = document.getElementById('pastedText').value.trim();

    if (!fileInput.files.length && !pasted) {
        errorBox.innerHTML = '<div class="alert alert-error">Please upload a file or paste some text.</div>';
        return;
    }

    btn.disabled = true;
    btn.innerHTML = '<span class="spinner"></span> Extracting...';

    const formData = new FormData();
    formData.append('csrf_token', csrfToken);
    if (fileInput.files.length) {
        formData.append('lesson_file', fileInput.files[0]);
    } else {
        formData.append('pasted_text', pasted);
    }

    try {
        const res = await fetch('extract_lesson_text.php', { method: 'POST', body: formData });
        const data = await res.json();

        if (!data.success) {
            errorBox.innerHTML = '<div class="alert alert-error">' + data.error + '</div>';
        } else {
            document.getElementById('extractedText').value = data.text;
            document.getElementById('extractedWrap').style.display = 'block';
            document.getElementById('extractedWrap').scrollIntoView({behavior: 'smooth'});
        }
    } catch (e) {
        errorBox.innerHTML = '<div class="alert alert-error">Request failed: ' + e.message + '</div>';
    }

    btn.disabled = false;
    btn.innerHTML = 'Extract Text';
}

async function generateFromLesson() {
    const btn = document.getElementById('generateBtn');
    const errorBox = document.getElementById('genError');
    errorBox.innerHTML = '';

    const subject = document.getElementById('subject').value;
    const lessonText = document.getElementById('extractedText').value.trim();

    if (!subject || !lessonText) {
        errorBox.innerHTML = '<div class="alert alert-error">Please select a subject and make sure there is extracted text.</div>';
        return;
    }

    btn.disabled = true;
    btn.innerHTML = '<span class="spinner"></span> Generating...';

    const payload = {
        csrf_token: csrfToken,
        subject: subject,
        class_level: document.getElementById('classLevel').value,
        lesson_text: lessonText,
        question_type: document.getElementById('questionType').value,
        difficulty: document.getElementById('difficulty').value,
        count: parseInt(document.getElementById('count').value || '10', 10),
    };

    try {
        const res = await fetch('lesson_to_questions.php', {
            method: 'POST',
            headers: {'Content-Type': 'application/json'},
            body: JSON.stringify(payload),
        });
        const data = await res.json();

        if (!data.success) {
            errorBox.innerHTML = '<div class="alert alert-error">' + data.error + '</div>';
        } else {
            currentMeta = { subject: payload.subject, class_level: payload.class_level, difficulty: payload.difficulty, question_type: payload.question_type };
            renderQuestions(data.questions, payload.question_type);
        }
    } catch (e) {
        errorBox.innerHTML = '<div class="alert alert-error">Request failed: ' + e.message + '</div>';
    }

    btn.disabled = false;
    btn.innerHTML = 'Generate Questions from this Note';
}

function renderQuestions(questions, type) {
    const wrap = document.getElementById('questionsPreview');
    wrap.innerHTML = '';

    questions.forEach((q, idx) => {
        const div = document.createElement('div');
        div.className = 'ai-question-preview';

        let optionsHtml = '';
        if (type === 'mcq') {
            (q.options || ['', '', '', '']).forEach((opt, i) => {
                optionsHtml += `
                    <div class="mcq-option-row">
                        <input type="radio" name="correct_${idx}" value="${i}" ${ (q.correct_index === i) ? 'checked' : '' } onchange="setCorrect(${idx}, ${i})">
                        <input type="text" class="opt-input" data-q="${idx}" data-opt="${i}" value="${escapeAttr(opt)}">
                    </div>`;
            });
        }

        div.innerHTML = `
            <label><input type="checkbox" class="include-check" data-q="${idx}" checked> Include this question</label>
            <label>Question</label>
            <textarea class="q-text" data-q="${idx}">${escapeHtml(q.question_text || '')}</textarea>
            ${ type === 'mcq'
                ? `<label>Options</label><div class="opts-wrap">${optionsHtml}</div>`
                : `<label>Model Answer</label><textarea class="theory-answer" data-q="${idx}">${escapeHtml(q.theory_answer || '')}</textarea>`
            }
        `;
        wrap.appendChild(div);
    });

    window.__generatedQuestions = questions;
    window.__questionType = type;

    document.getElementById('resultsWrap').style.display = 'block';
    document.getElementById('resultsWrap').scrollIntoView({behavior: 'smooth'});
}

function setCorrect(qIdx, optIdx) {
    window.__generatedQuestions[qIdx].correct_index = optIdx;
}

function escapeHtml(str) {
    return (str || '').replace(/[&<>"]/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'}[c]));
}
function escapeAttr(str) { return escapeHtml(str); }

async function saveQuestions() {
    const type = window.__questionType;
    const checks = document.querySelectorAll('.include-check');
    const questionsToSave = [];

    checks.forEach(chk => {
        if (!chk.checked) return;
        const idx = chk.dataset.q;
        const textEl = document.querySelector(`.q-text[data-q="${idx}"]`);
        const questionText = textEl.value.trim();

        if (type === 'mcq') {
            const optionInputs = document.querySelectorAll(`.opt-input[data-q="${idx}"]`);
            const options = Array.from(optionInputs).map(i => i.value);
            const correctRadio = document.querySelector(`input[name="correct_${idx}"]:checked`);
            questionsToSave.push({
                question_type: 'mcq',
                question_text: questionText,
                options: options,
                correct_index: correctRadio ? parseInt(correctRadio.value, 10) : 0,
            });
        } else {
            const ansEl = document.querySelector(`.theory-answer[data-q="${idx}"]`);
            questionsToSave.push({
                question_type: 'theory',
                question_text: questionText,
                theory_answer: ansEl.value.trim(),
            });
        }
    });

    const msgBox = document.getElementById('saveMsg');
    if (questionsToSave.length === 0) {
        msgBox.innerHTML = '<div class="alert alert-error">No questions selected.</div>';
        return;
    }

    const payload = {
        csrf_token: csrfToken,
        subject: currentMeta.subject,
        class_level: currentMeta.class_level,
        difficulty: currentMeta.difficulty,
        source: 'lesson_note',
        questions: questionsToSave,
    };

    const res = await fetch('save_bulk_questions.php', {
        method: 'POST',
        headers: {'Content-Type': 'application/json'},
        body: JSON.stringify(payload),
    });
    const data = await res.json();

    if (data.success) {
        msgBox.innerHTML = '<div class="alert alert-success">' + data.saved + ' question(s) submitted for admin review.</div>';
        document.getElementById('resultsWrap').style.display = 'none';
    } else {
        msgBox.innerHTML = '<div class="alert alert-error">' + data.error + '</div>';
    }
}
</script>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>
