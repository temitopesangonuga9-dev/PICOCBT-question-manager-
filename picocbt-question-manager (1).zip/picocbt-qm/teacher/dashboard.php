<?php
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/functions.php';
requireTeacher();

$teacherId = $_SESSION['user_id'];

$stmt = $pdo->prepare("SELECT status, COUNT(*) as cnt FROM question_bank WHERE created_by = ? GROUP BY status");
$stmt->execute([$teacherId]);
$counts = ['draft' => 0, 'pending' => 0, 'approved' => 0, 'rejected' => 0];
foreach ($stmt->fetchAll() as $row) {
    $counts[$row['status']] = (int) $row['cnt'];
}
$total = array_sum($counts);

$pageTitle = 'Teacher Dashboard';
$assetPath = '../assets/';
require_once __DIR__ . '/../includes/header.php';
?>

<div class="stat-grid">
    <div class="stat-box"><div class="num"><?= $total ?></div><div class="lbl">Total Questions</div></div>
    <div class="stat-box"><div class="num"><?= $counts['pending'] ?></div><div class="lbl">Pending Review</div></div>
    <div class="stat-box"><div class="num"><?= $counts['approved'] ?></div><div class="lbl">Approved</div></div>
    <div class="stat-box"><div class="num"><?= $counts['rejected'] ?></div><div class="lbl">Rejected</div></div>
</div>

<div class="grid-2">
    <div class="card">
        <div class="card-header">✍️ Create a Question Manually</div>
        <div class="card-body">
            <p>Write an MCQ or theory question yourself, subject by subject.</p>
            <a href="create_question.php" class="btn">Create Question</a>
        </div>
    </div>
    <div class="card">
        <div class="card-header">🤖 Generate Questions with AI</div>
        <div class="card-body">
            <p>Give a topic and let AI draft a batch of MCQs or theory questions for you to review.</p>
            <a href="ai_generate.php" class="btn">Generate with AI</a>
        </div>
    </div>
    <div class="card">
        <div class="card-header">📄 Lesson Note &rarr; MCQ</div>
        <div class="card-body">
            <p>Upload a lesson note (.txt, .docx, .pdf) or paste text, and AI will turn it into exam questions.</p>
            <a href="upload_lesson.php" class="btn">Convert Lesson Note</a>
        </div>
    </div>
    <div class="card">
        <div class="card-header">📋 My Questions</div>
        <div class="card-body">
            <p>View, edit, and track the status of every question you've submitted.</p>
            <a href="my_questions.php" class="btn">View My Questions</a>
        </div>
    </div>
</div>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>
