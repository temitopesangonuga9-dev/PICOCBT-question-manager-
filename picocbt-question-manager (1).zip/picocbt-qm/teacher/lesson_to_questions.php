<?php
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../config/openai.php';
header('Content-Type: application/json');

if (!isTeacher()) {
    http_response_code(403);
    echo json_encode(['success' => false, 'error' => 'Not authorized.']);
    exit;
}

$input = json_decode(file_get_contents('php://input'), true) ?? [];

if (!verifyCsrf($input['csrf_token'] ?? null)) {
    echo json_encode(['success' => false, 'error' => 'Invalid session token, please refresh the page.']);
    exit;
}

$subject      = trim($input['subject'] ?? '');
$classLevel   = trim($input['class_level'] ?? '');
$lessonText   = trim($input['lesson_text'] ?? '');
$questionType = $input['question_type'] ?? 'mcq';
$difficulty   = $input['difficulty'] ?? 'medium';
$count        = max(1, min(20, (int) ($input['count'] ?? 10)));

if ($subject === '' || $lessonText === '') {
    echo json_encode(['success' => false, 'error' => 'Subject and lesson note text are required.']);
    exit;
}

// Trim very long lesson notes to keep within reasonable token limits.
$maxChars = 12000;
if (mb_strlen($lessonText) > $maxChars) {
    $lessonText = mb_substr($lessonText, 0, $maxChars);
}

// Save the lesson upload record for the teacher's history.
$stmt = $pdo->prepare("INSERT INTO lesson_uploads (teacher_id, subject, extracted_text, status) VALUES (?, ?, ?, 'processed')");
$stmt->execute([$_SESSION['user_id'], $subject, $lessonText]);

$systemPrompt = "You are an expert Nigerian secondary school exam-question writer for Progress Intellectual College Okeigbo (PICOCBT). "
    . "You create exam questions strictly based on the lesson note content provided, without introducing facts not covered in the note. "
    . "Always reply with ONLY a valid JSON object of the exact shape requested, no extra commentary, no markdown fences.";

if ($questionType === 'mcq') {
    $userPrompt = "Based ONLY on the lesson note below for the subject \"$subject\""
        . ($classLevel ? " ($classLevel)" : "")
        . ", generate $count multiple choice exam questions (MCQs), difficulty: $difficulty.\n"
        . "Each question must have exactly 4 options with exactly ONE correct answer.\n"
        . "Respond with JSON in this exact shape:\n"
        . '{"questions": [{"question_text": "...", "options": ["...","...","...","..."], "correct_index": 0}]}' . "\n\n"
        . "LESSON NOTE:\n\"\"\"\n$lessonText\n\"\"\"";
} else {
    $userPrompt = "Based ONLY on the lesson note below for the subject \"$subject\""
        . ($classLevel ? " ($classLevel)" : "")
        . ", generate $count theory exam questions with concise model answers, difficulty: $difficulty.\n"
        . "Respond with JSON in this exact shape:\n"
        . '{"questions": [{"question_text": "...", "theory_answer": "..."}]}' . "\n\n"
        . "LESSON NOTE:\n\"\"\"\n$lessonText\n\"\"\"";
}

$result = callOpenAI($systemPrompt, $userPrompt, 0.4);

if (!$result['success']) {
    echo json_encode(['success' => false, 'error' => $result['error']]);
    exit;
}

$parsed = json_decode($result['content'], true);

if (!$parsed || !isset($parsed['questions']) || !is_array($parsed['questions'])) {
    echo json_encode(['success' => false, 'error' => 'AI returned an unexpected format. Please try again.']);
    exit;
}

echo json_encode(['success' => true, 'questions' => $parsed['questions']]);
