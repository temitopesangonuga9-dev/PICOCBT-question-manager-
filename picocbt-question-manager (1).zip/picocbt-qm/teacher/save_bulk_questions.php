<?php
require_once __DIR__ . '/../includes/auth.php';
header('Content-Type: application/json');

if (!isTeacher()) {
    http_response_code(403);
    echo json_encode(['success' => false, 'error' => 'Not authorized.']);
    exit;
}

$input = json_decode(file_get_contents('php://input'), true) ?? [];

if (!verifyCsrf($input['csrf_token'] ?? null)) {
    http_response_code(400);
    echo json_encode(['success' => false, 'error' => 'Invalid session token, please refresh the page.']);
    exit;
}

$subject      = trim($input['subject'] ?? '');
$classLevel   = trim($input['class_level'] ?? '');
$difficulty   = $input['difficulty'] ?? 'medium';
$source       = in_array($input['source'] ?? '', ['ai_generated', 'lesson_note']) ? $input['source'] : 'ai_generated';
$questions    = $input['questions'] ?? [];

if ($subject === '' || empty($questions)) {
    echo json_encode(['success' => false, 'error' => 'Missing subject or questions to save.']);
    exit;
}

$saved = 0;
$pdo->beginTransaction();

try {
    $qStmt = $pdo->prepare(
        "INSERT INTO question_bank (subject, class_level, question_type, question_text, theory_answer, difficulty, created_by, status, source)
         VALUES (?, ?, ?, ?, ?, ?, ?, 'pending', ?)"
    );
    $optStmt = $pdo->prepare("INSERT INTO question_bank_options (question_id, option_text, is_correct) VALUES (?, ?, ?)");

    foreach ($questions as $q) {
        $type = ($q['question_type'] ?? 'mcq') === 'theory' ? 'theory' : 'mcq';
        $text = trim($q['question_text'] ?? '');
        if ($text === '') continue;

        $qStmt->execute([
            $subject, $classLevel, $type, $text,
            $type === 'theory' ? trim($q['theory_answer'] ?? '') : null,
            $difficulty, $_SESSION['user_id'], $source,
        ]);
        $questionId = $pdo->lastInsertId();

        if ($type === 'mcq' && !empty($q['options']) && is_array($q['options'])) {
            $correctIndex = (int) ($q['correct_index'] ?? 0);
            foreach ($q['options'] as $i => $optText) {
                $optText = trim($optText);
                if ($optText === '') continue;
                $optStmt->execute([$questionId, $optText, ($i === $correctIndex) ? 1 : 0]);
            }
        }
        $saved++;
    }

    $pdo->commit();
    echo json_encode(['success' => true, 'saved' => $saved]);
} catch (Throwable $e) {
    $pdo->rollBack();
    echo json_encode(['success' => false, 'error' => 'Failed to save: ' . $e->getMessage()]);
}
