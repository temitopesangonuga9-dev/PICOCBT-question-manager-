<?php
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/functions.php';

if (isLoggedIn()) redirect('dashboard.php');

$errors = [];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!verifyCsrf($_POST['csrf_token'] ?? null)) {
        $errors[] = 'Invalid form submission, please try again.';
    } else {
        $fullName = trim($_POST['full_name'] ?? '');
        $email    = trim($_POST['email'] ?? '');
        $subject  = trim($_POST['subject'] ?? '');
        $password = $_POST['password'] ?? '';
        $confirm  = $_POST['confirm_password'] ?? '';

        if ($fullName === '' || $email === '' || $password === '') {
            $errors[] = 'Please fill in all required fields.';
        }
        if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
            $errors[] = 'Please enter a valid email address.';
        }
        if (strlen($password) < 6) {
            $errors[] = 'Password must be at least 6 characters.';
        }
        if ($password !== $confirm) {
            $errors[] = 'Passwords do not match.';
        }

        if (empty($errors)) {
            $stmt = $pdo->prepare("SELECT id FROM users WHERE email = ?");
            $stmt->execute([$email]);
            if ($stmt->fetch()) {
                $errors[] = 'An account with that email already exists.';
            } else {
                $stmt = $pdo->prepare(
                    "INSERT INTO users (full_name, email, password, role, subject, status) VALUES (?, ?, ?, 'teacher', ?, 'pending')"
                );
                $stmt->execute([$fullName, $email, password_hash($password, PASSWORD_DEFAULT), $subject]);
                setFlash('success', 'Registration successful! An admin must approve your account before you can log in.');
                redirect('login.php');
            }
        }
    }
}

$pageTitle = 'Teacher Registration';
$assetPath = '../assets/';
require_once __DIR__ . '/../includes/header.php';
?>
<div class="card card-narrow">
    <div class="card-header">Teacher Registration</div>
    <div class="card-body">
        <?php foreach ($errors as $err): ?>
            <div class="alert alert-error"><?= e($err) ?></div>
        <?php endforeach; ?>
        <form method="post">
            <input type="hidden" name="csrf_token" value="<?= e(csrfToken()) ?>">
            <label>Full Name</label>
            <input type="text" name="full_name" value="<?= e($_POST['full_name'] ?? '') ?>" required>

            <label>Email</label>
            <input type="email" name="email" value="<?= e($_POST['email'] ?? '') ?>" required>

            <label>Subject you teach</label>
            <select name="subject" required>
                <option value="">-- Select subject --</option>
                <?php foreach (subjectList() as $s): ?>
                    <option value="<?= e($s) ?>" <?= (($_POST['subject'] ?? '') === $s) ? 'selected' : '' ?>><?= e($s) ?></option>
                <?php endforeach; ?>
            </select>

            <label>Password</label>
            <input type="password" name="password" required>

            <label>Confirm Password</label>
            <input type="password" name="confirm_password" required>

            <button type="submit" class="btn btn-block">Register</button>
        </form>
        <div class="helper-links">
            <a href="login.php">Already have an account? Login</a>
        </div>
    </div>
</div>
<?php require_once __DIR__ . '/../includes/footer.php'; ?>
