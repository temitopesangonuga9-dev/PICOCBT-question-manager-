<?php
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../config/openai.php';
header('Content-Type: application/json');

if (!isTeacher()) {
    http_response_code(403);
    echo json_encode(['success' => false, 'error' => 'Not authorized.']);
    exit;
}

$input = json_decode(file_get_contents('php://input'), true) ?? [];

if (!verifyCsrf($input['csrf_token'] ?? null)) {
    http_response_code(400);
    echo json_encode(['success' => false, 'error' => 'Invalid session token, please refresh the page.']);
    exit;
}

$subject      = trim($input['subject'] ?? '');
$topic        = trim($input['topic'] ?? '');
$classLevel   = trim($input['class_level'] ?? '');
$questionType = $input['question_type'] ?? 'mcq';
$difficulty   = $input['difficulty'] ?? 'medium';
$count        = max(1, min(20, (int) ($input['count'] ?? 5)));

if ($subject === '' || $topic === '') {
    echo json_encode(['success' => false, 'error' => 'Subject and topic are required.']);
    exit;
}

$systemPrompt = "You are an expert Nigerian secondary school exam-question writer for Progress Intellectual College Okeigbo (PICOCBT). "
    . "You write clear, curriculum-appropriate, unambiguous exam questions. "
    . "Always reply with ONLY a valid JSON object of the exact shape requested, no extra commentary, no markdown fences.";

if ($questionType === 'mcq') {
    $userPrompt = "Generate $count multiple choice questions (MCQs) for the subject \"$subject\""
        . ($classLevel ? " at class level $classLevel" : "")
        . " on the topic: \"$topic\". Difficulty: $difficulty.\n"
        . "Each question must have exactly 4 options with exactly ONE correct answer.\n"
        . "Respond with JSON in this exact shape:\n"
        . '{"questions": [{"question_text": "...", "options": ["...","...","...","..."], "correct_index": 0}]}';
} else {
    $userPrompt = "Generate $count theory (essay/short-answer) exam questions for the subject \"$subject\""
        . ($classLevel ? " at class level $classLevel" : "")
        . " on the topic: \"$topic\". Difficulty: $difficulty.\n"
        . "Each question must include a concise model answer / marking guide.\n"
        . "Respond with JSON in this exact shape:\n"
        . '{"questions": [{"question_text": "...", "theory_answer": "..."}]}';
}

$result = callOpenAI($systemPrompt, $userPrompt, 0.5);

if (!$result['success']) {
    echo json_encode(['success' => false, 'error' => $result['error']]);
    exit;
}

$parsed = json_decode($result['content'], true);

if (!$parsed || !isset($parsed['questions']) || !is_array($parsed['questions'])) {
    echo json_encode(['success' => false, 'error' => 'AI returned an unexpected format. Please try again.']);
    exit;
}

echo json_encode([
    'success'   => true,
    'questions' => $parsed['questions'],
    'meta'      => compact('subject', 'topic', 'classLevel', 'questionType', 'difficulty'),
]);
