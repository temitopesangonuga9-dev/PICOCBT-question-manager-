<?php
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/functions.php';
requireTeacher();

$stmt = $pdo->prepare(
    "SELECT id, subject, class_level, question_type, question_text, status, source, created_at
     FROM question_bank WHERE created_by = ? ORDER BY created_at DESC LIMIT 300"
);
$stmt->execute([$_SESSION['user_id']]);
$questions = $stmt->fetchAll();

$pageTitle = 'My Questions';
$assetPath = '../assets/';
require_once __DIR__ . '/../includes/header.php';
?>

<div class="card">
    <div class="card-header">My Questions (<?= count($questions) ?>)</div>
    <div class="card-body">
        <?php if (empty($questions)): ?>
            <p>You haven't submitted any questions yet. <a href="dashboard.php">Go create some.</a></p>
        <?php else: ?>
        <table>
            <thead>
                <tr><th>Subject</th><th>Class</th><th>Type</th><th>Question</th><th>Source</th><th>Status</th><th>Submitted</th></tr>
            </thead>
            <tbody>
                <?php foreach ($questions as $q): ?>
                <tr>
                    <td><?= e($q['subject']) ?></td>
                    <td><?= e($q['class_level'] ?? '-') ?></td>
                    <td><?= e(ucfirst($q['question_type'])) ?></td>
                    <td><?= e(mb_strimwidth($q['question_text'], 0, 80, '...')) ?></td>
                    <td><?= e(str_replace('_', ' ', ucfirst($q['source']))) ?></td>
                    <td><span class="badge badge-<?= e($q['status']) ?>"><?= e(ucfirst($q['status'])) ?></span></td>
                    <td><?= e(date('d M Y', strtotime($q['created_at']))) ?></td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
        <?php endif; ?>
    </div>
</div>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>
