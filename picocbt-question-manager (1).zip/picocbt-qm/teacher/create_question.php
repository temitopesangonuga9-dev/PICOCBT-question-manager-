<?php
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/functions.php';
requireTeacher();

$errors = [];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!verifyCsrf($_POST['csrf_token'] ?? null)) {
        $errors[] = 'Invalid form submission, please try again.';
    } else {
        $subject      = trim($_POST['subject'] ?? '');
        $classLevel   = trim($_POST['class_level'] ?? '');
        $questionType = $_POST['question_type'] ?? 'mcq';
        $questionText = trim($_POST['question_text'] ?? '');
        $difficulty   = $_POST['difficulty'] ?? 'medium';
        $theoryAnswer = trim($_POST['theory_answer'] ?? '');
        $options      = $_POST['options'] ?? [];
        $correctIndex = $_POST['correct_option'] ?? null;

        if ($subject === '' || $questionText === '') {
            $errors[] = 'Subject and question text are required.';
        }
        if ($questionType === 'mcq') {
            $filledOptions = array_filter($options, fn($o) => trim($o) !== '');
            if (count($filledOptions) < 2) {
                $errors[] = 'Please provide at least 2 options for an MCQ.';
            }
            if ($correctIndex === null || !isset($options[$correctIndex]) || trim($options[$correctIndex]) === '') {
                $errors[] = 'Please select which option is correct.';
            }
        } else {
            if ($theoryAnswer === '') {
                $errors[] = 'Please provide a model answer for the theory question.';
            }
        }

        if (empty($errors)) {
            $pdo->beginTransaction();
            $stmt = $pdo->prepare(
                "INSERT INTO question_bank (subject, class_level, question_type, question_text, theory_answer, difficulty, created_by, status, source)
                 VALUES (?, ?, ?, ?, ?, ?, ?, 'pending', 'manual')"
            );
            $stmt->execute([
                $subject, $classLevel, $questionType, $questionText,
                $questionType === 'theory' ? $theoryAnswer : null,
                $difficulty, $_SESSION['user_id'],
            ]);
            $questionId = $pdo->lastInsertId();

            if ($questionType === 'mcq') {
                $optStmt = $pdo->prepare("INSERT INTO question_bank_options (question_id, option_text, is_correct) VALUES (?, ?, ?)");
                foreach ($options as $i => $optText) {
                    $optText = trim($optText);
                    if ($optText === '') continue;
                    $optStmt->execute([$questionId, $optText, ($i == $correctIndex) ? 1 : 0]);
                }
            }
            $pdo->commit();

            setFlash('success', 'Question submitted for admin review.');
            redirect('my_questions.php');
        }
    }
}

$pageTitle = 'Create Question';
$assetPath = '../assets/';
require_once __DIR__ . '/../includes/header.php';
?>

<div class="card">
    <div class="card-header">Create a Question</div>
    <div class="card-body">
        <?php foreach ($errors as $err): ?><div class="alert alert-error"><?= e($err) ?></div><?php endforeach; ?>

        <form method="post" id="qForm">
            <input type="hidden" name="csrf_token" value="<?= e(csrfToken()) ?>">

            <div class="grid-2">
                <div>
                    <label>Subject</label>
                    <select name="subject" required>
                        <option value="">-- Select --</option>
                        <?php foreach (subjectList() as $s): ?>
                            <option value="<?= e($s) ?>" <?= (($_SESSION['subject'] ?? '') === $s) ? 'selected' : '' ?>><?= e($s) ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div>
                    <label>Class Level</label>
                    <select name="class_level">
                        <option value="JSS1">JSS1</option>
                        <option value="JSS2">JSS2</option>
                        <option value="JSS3">JSS3</option>
                        <option value="SS1">SS1</option>
                        <option value="SS2">SS2</option>
                        <option value="SS3">SS3</option>
                    </select>
                </div>
            </div>

            <label>Question Type</label>
            <select name="question_type" id="questionType" onchange="toggleType()">
                <option value="mcq">Multiple Choice (MCQ)</option>
                <option value="theory">Theory</option>
            </select>

            <label>Difficulty</label>
            <select name="difficulty">
                <option value="easy">Easy</option>
                <option value="medium" selected>Medium</option>
                <option value="hard">Hard</option>
            </select>

            <label>Question Text</label>
            <textarea name="question_text" required placeholder="Type the question here. LaTeX supported, e.g. $x^2 + 2x = 0$"></textarea>

            <div id="mcqFields">
                <label>Options (tick the correct one)</label>
                <div id="optionsWrap">
                    <?php for ($i = 0; $i < 4; $i++): ?>
                    <div class="mcq-option-row">
                        <input type="radio" name="correct_option" value="<?= $i ?>" <?= $i === 0 ? 'checked' : '' ?>>
                        <input type="text" name="options[]" placeholder="Option <?= chr(65 + $i) ?>">
                    </div>
                    <?php endfor; ?>
                </div>
            </div>

            <div id="theoryFields" style="display:none;">
                <label>Model Answer</label>
                <textarea name="theory_answer" placeholder="Expected answer / marking guide"></textarea>
            </div>

            <button type="submit" class="btn btn-block">Submit for Review</button>
        </form>
    </div>
</div>

<script>
function toggleType() {
    const type = document.getElementById('questionType').value;
    document.getElementById('mcqFields').style.display = type === 'mcq' ? 'block' : 'none';
    document.getElementById('theoryFields').style.display = type === 'theory' ? 'block' : 'none';
}
</script>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>
