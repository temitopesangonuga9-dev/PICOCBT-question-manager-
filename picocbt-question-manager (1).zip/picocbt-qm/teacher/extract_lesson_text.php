<?php
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/file_parser.php';
header('Content-Type: application/json');

if (!isTeacher()) {
    http_response_code(403);
    echo json_encode(['success' => false, 'error' => 'Not authorized.']);
    exit;
}

if (!verifyCsrf($_POST['csrf_token'] ?? null)) {
    echo json_encode(['success' => false, 'error' => 'Invalid session token, please refresh the page.']);
    exit;
}

$pastedText = trim($_POST['pasted_text'] ?? '');

// If the teacher pasted text directly, use that.
if ($pastedText !== '') {
    echo json_encode(['success' => true, 'text' => $pastedText]);
    exit;
}

// Otherwise expect an uploaded file.
if (empty($_FILES['lesson_file']) || $_FILES['lesson_file']['error'] !== UPLOAD_ERR_OK) {
    echo json_encode(['success' => false, 'error' => 'Please upload a file or paste lesson note text.']);
    exit;
}

$allowedExt = ['txt', 'docx', 'pdf'];
$ext = strtolower(pathinfo($_FILES['lesson_file']['name'], PATHINFO_EXTENSION));

if (!in_array($ext, $allowedExt)) {
    echo json_encode(['success' => false, 'error' => 'Only .txt, .docx and .pdf files are supported.']);
    exit;
}

$uploadDir = __DIR__ . '/../uploads/lesson_notes';
if (!is_dir($uploadDir)) {
    mkdir($uploadDir, 0755, true);
}

$safeName = 'lesson_' . time() . '_' . bin2hex(random_bytes(4)) . '.' . $ext;
$destPath = $uploadDir . '/' . $safeName;

if (!move_uploaded_file($_FILES['lesson_file']['tmp_name'], $destPath)) {
    echo json_encode(['success' => false, 'error' => 'Failed to save uploaded file.']);
    exit;
}

$result = extractTextFromUpload($destPath, $ext);

if (!$result['success']) {
    echo json_encode(['success' => false, 'error' => $result['error']]);
    exit;
}

echo json_encode(['success' => true, 'text' => $result['text']]);
