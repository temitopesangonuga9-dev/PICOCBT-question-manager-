<?php
/**
 * PICOCBT Question Manager - Database Migration
 * -----------------------------------------------------
 * Run this ONCE from your browser (or CLI) after configuring config/db.php:
 *   http://localhost/picocbt-qm/sql/migration.php
 *
 * It is SAFE to run more than once - every step checks whether the
 * table/column already exists before creating/adding it, so it will
 * never touch or duplicate your existing PICOCBT question_bank data.
 */

require_once __DIR__ . '/../config/db.php';

$log = [];

function tableExists(PDO $pdo, string $table): bool
{
    $stmt = $pdo->prepare("SELECT COUNT(*) FROM information_schema.tables WHERE table_schema = DATABASE() AND table_name = ?");
    $stmt->execute([$table]);
    return (bool) $stmt->fetchColumn();
}

function columnExists(PDO $pdo, string $table, string $column): bool
{
    $stmt = $pdo->prepare("SELECT COUNT(*) FROM information_schema.columns WHERE table_schema = DATABASE() AND table_name = ? AND column_name = ?");
    $stmt->execute([$table, $column]);
    return (bool) $stmt->fetchColumn();
}

// 1. users table (teachers + admins for THIS tool) --------------------------
if (!tableExists($pdo, 'users')) {
    $pdo->exec("
        CREATE TABLE users (
            id INT AUTO_INCREMENT PRIMARY KEY,
            full_name VARCHAR(150) NOT NULL,
            email VARCHAR(150) NOT NULL UNIQUE,
            password VARCHAR(255) NOT NULL,
            role ENUM('admin','teacher') NOT NULL DEFAULT 'teacher',
            subject VARCHAR(100) NULL,
            status ENUM('pending','active','suspended') NOT NULL DEFAULT 'pending',
            created_at DATETIME DEFAULT CURRENT_TIMESTAMP
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4
    ");
    $log[] = "Created table: users";
} else {
    $log[] = "Table 'users' already exists - skipped.";
}

// 2. question_bank table (create fresh only if it doesn't already exist -----
//    from your existing PICOCBT setup; otherwise we only ADD columns below)
if (!tableExists($pdo, 'question_bank')) {
    $pdo->exec("
        CREATE TABLE question_bank (
            id INT AUTO_INCREMENT PRIMARY KEY,
            subject VARCHAR(100) NOT NULL,
            class_level VARCHAR(50) NULL,
            question_type ENUM('mcq','theory') NOT NULL DEFAULT 'mcq',
            question_text TEXT NOT NULL,
            theory_answer TEXT NULL,
            difficulty ENUM('easy','medium','hard') DEFAULT 'medium',
            created_at DATETIME DEFAULT CURRENT_TIMESTAMP
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4
    ");
    $log[] = "Created table: question_bank";
} else {
    $log[] = "Table 'question_bank' already exists - only new columns will be added.";
}

if (!tableExists($pdo, 'question_bank_options')) {
    $pdo->exec("
        CREATE TABLE question_bank_options (
            id INT AUTO_INCREMENT PRIMARY KEY,
            question_id INT NOT NULL,
            option_text TEXT NOT NULL,
            is_correct TINYINT(1) NOT NULL DEFAULT 0,
            FOREIGN KEY (question_id) REFERENCES question_bank(id) ON DELETE CASCADE
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4
    ");
    $log[] = "Created table: question_bank_options";
} else {
    $log[] = "Table 'question_bank_options' already exists - skipped.";
}

// 3. Extend question_bank with the columns this tool needs, IF missing ------
$newColumns = [
    'created_by'   => "ALTER TABLE question_bank ADD COLUMN created_by INT NULL AFTER id",
    'status'       => "ALTER TABLE question_bank ADD COLUMN status ENUM('draft','pending','approved','rejected') NOT NULL DEFAULT 'pending'",
    'source'       => "ALTER TABLE question_bank ADD COLUMN source ENUM('manual','ai_generated','lesson_note') NOT NULL DEFAULT 'manual'",
    'reviewed_by'  => "ALTER TABLE question_bank ADD COLUMN reviewed_by INT NULL",
    'reviewed_at'  => "ALTER TABLE question_bank ADD COLUMN reviewed_at DATETIME NULL",
];

foreach ($newColumns as $col => $sql) {
    if (!columnExists($pdo, 'question_bank', $col)) {
        $pdo->exec($sql);
        $log[] = "Added column question_bank.$col";
    } else {
        $log[] = "Column question_bank.$col already exists - skipped.";
    }
}

// 4. lesson_uploads table -----------------------------------------------------
if (!tableExists($pdo, 'lesson_uploads')) {
    $pdo->exec("
        CREATE TABLE lesson_uploads (
            id INT AUTO_INCREMENT PRIMARY KEY,
            teacher_id INT NOT NULL,
            subject VARCHAR(100) NOT NULL,
            title VARCHAR(200) NULL,
            original_filename VARCHAR(255) NULL,
            extracted_text LONGTEXT NULL,
            status ENUM('processed','failed') NOT NULL DEFAULT 'processed',
            created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (teacher_id) REFERENCES users(id) ON DELETE CASCADE
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4
    ");
    $log[] = "Created table: lesson_uploads";
} else {
    $log[] = "Table 'lesson_uploads' already exists - skipped.";
}

// 5. csv_exports table (audit trail of admin downloads) ----------------------
if (!tableExists($pdo, 'csv_exports')) {
    $pdo->exec("
        CREATE TABLE csv_exports (
            id INT AUTO_INCREMENT PRIMARY KEY,
            admin_id INT NOT NULL,
            filters TEXT NULL,
            question_count INT DEFAULT 0,
            created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (admin_id) REFERENCES users(id) ON DELETE CASCADE
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4
    ");
    $log[] = "Created table: csv_exports";
} else {
    $log[] = "Table 'csv_exports' already exists - skipped.";
}

// 6. Seed a default admin account if no admin exists yet ---------------------
$adminCount = $pdo->query("SELECT COUNT(*) FROM users WHERE role = 'admin'")->fetchColumn();
if ($adminCount == 0) {
    $defaultEmail = 'admin@picoict.ng';
    $defaultPass  = 'ChangeMe123!';
    $stmt = $pdo->prepare("INSERT INTO users (full_name, email, password, role, status) VALUES (?, ?, ?, 'admin', 'active')");
    $stmt->execute(['PICOCBT Admin', $defaultEmail, password_hash($defaultPass, PASSWORD_DEFAULT)]);
    $log[] = "Seeded default admin account -> email: $defaultEmail / password: $defaultPass (PLEASE CHANGE THIS AFTER FIRST LOGIN)";
} else {
    $log[] = "Admin account already exists - skipped seeding.";
}

echo "<h2>PICOCBT Question Manager - Migration Log</h2><ul>";
foreach ($log as $line) {
    echo "<li>" . htmlspecialchars($line) . "</li>";
}
echo "</ul><p>Done. You can now delete or restrict access to this file.</p>";
