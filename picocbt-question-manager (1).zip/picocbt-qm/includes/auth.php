<?php
/**
 * PICOCBT Question Manager - Authentication Helpers
 */

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

require_once __DIR__ . '/../config/db.php';

/** Redirect helper */
function redirect(string $url): void
{
    header("Location: $url");
    exit;
}

/** Is anyone logged in? */
function isLoggedIn(): bool
{
    return isset($_SESSION['user_id']);
}

/** Is the logged-in user a teacher? */
function isTeacher(): bool
{
    return isLoggedIn() && ($_SESSION['role'] ?? '') === 'teacher';
}

/** Is the logged-in user an admin? */
function isAdmin(): bool
{
    return isLoggedIn() && ($_SESSION['role'] ?? '') === 'admin';
}

/** Force teacher-only pages to redirect non-teachers to the teacher login */
function requireTeacher(): void
{
    if (!isTeacher()) {
        redirect('login.php');
    }
}

/** Force admin-only pages to redirect non-admins to the admin login */
function requireAdmin(): void
{
    if (!isAdmin()) {
        redirect('login.php');
    }
}

/**
 * Attempt to log a user in.
 * @return array ['success'=>bool, 'error'=>string|null]
 */
function attemptLogin(PDO $pdo, string $email, string $password, string $expectedRole): array
{
    $stmt = $pdo->prepare("SELECT * FROM users WHERE email = ? AND role = ? LIMIT 1");
    $stmt->execute([$email, $expectedRole]);
    $user = $stmt->fetch();

    if (!$user || !password_verify($password, $user['password'])) {
        return ['success' => false, 'error' => 'Invalid email or password.'];
    }

    if ($expectedRole === 'teacher' && $user['status'] !== 'active') {
        return ['success' => false, 'error' => 'Your teacher account is still pending admin approval.'];
    }

    $_SESSION['user_id']   = $user['id'];
    $_SESSION['full_name'] = $user['full_name'];
    $_SESSION['role']      = $user['role'];
    $_SESSION['subject']   = $user['subject'];

    return ['success' => true, 'error' => null];
}

function logoutUser(): void
{
    $_SESSION = [];
    session_destroy();
}
