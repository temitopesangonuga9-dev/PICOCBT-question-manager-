<?php
/**
 * Expects (optionally) $pageTitle to be set before including this file.
 */
$pageTitle = $pageTitle ?? 'PICOCBT Question Manager';
// $assetPath should be set by the including page: 'assets/' for root pages,
// '../assets/' for pages inside /teacher or /admin.
$assetPath = $assetPath ?? '../assets/';
$flash = getFlash();
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title><?= e($pageTitle) ?></title>
<link rel="stylesheet" href="<?= e($assetPath) ?>style.css">
</head>
<body>
<header class="topbar">
    <div class="topbar-inner">
        <span class="brand">PICOCBT Question Manager</span>
        <?php if (isLoggedIn()): ?>
        <nav class="topnav">
            <span class="whoami">👤 <?= e($_SESSION['full_name']) ?> (<?= e(ucfirst($_SESSION['role'])) ?>)</span>
            <a href="logout.php" class="btn-link">Logout</a>
        </nav>
        <?php endif; ?>
    </div>
</header>
<main class="page-wrap">
    <?php if ($flash): ?>
        <div class="alert alert-<?= e($flash['type']) ?>"><?= e($flash['message']) ?></div>
    <?php endif; ?>
