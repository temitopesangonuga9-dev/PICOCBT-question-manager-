<?php
/**
 * PICOCBT Question Manager - Lesson Note Text Extractor
 * -----------------------------------------------------
 * Supports .txt, .docx and .pdf without requiring Composer/internet access,
 * so it works on plain XAMPP out of the box.
 *
 * .docx  -> read via PHP's built-in ZipArchive (docx is a zip of XML files)
 * .pdf   -> tries the `pdftotext` command-line tool if installed (comes with
 *           Xpdf/Poppler-utils). If it isn't available, returns an error asking
 *           the teacher to paste the text manually or install pdftotext.
 * .txt   -> read directly
 */

function extractTextFromUpload(string $filePath, string $extension): array
{
    $extension = strtolower($extension);

    try {
        switch ($extension) {
            case 'txt':
                $text = file_get_contents($filePath);
                return ['success' => true, 'text' => $text, 'error' => null];

            case 'docx':
                return extractTextFromDocx($filePath);

            case 'pdf':
                return extractTextFromPdf($filePath);

            default:
                return ['success' => false, 'text' => null, 'error' => 'Unsupported file type: .' . $extension];
        }
    } catch (Throwable $e) {
        return ['success' => false, 'text' => null, 'error' => 'Failed to read file: ' . $e->getMessage()];
    }
}

function extractTextFromDocx(string $filePath): array
{
    if (!class_exists('ZipArchive')) {
        return ['success' => false, 'text' => null, 'error' => 'PHP Zip extension is not enabled (needed to read .docx).'];
    }

    $zip = new ZipArchive();
    if ($zip->open($filePath) !== true) {
        return ['success' => false, 'text' => null, 'error' => 'Could not open the .docx file (it may be corrupted).'];
    }

    $xml = $zip->getFromName('word/document.xml');
    $zip->close();

    if ($xml === false) {
        return ['success' => false, 'text' => null, 'error' => 'Could not find document content inside the .docx file.'];
    }

    // Preserve paragraph breaks, then strip remaining XML tags.
    $xml = str_replace('</w:p>', "\n", $xml);
    $text = strip_tags($xml);
    $text = html_entity_decode($text, ENT_QUOTES, 'UTF-8');
    $text = preg_replace("/\n{3,}/", "\n\n", trim($text));

    return ['success' => true, 'text' => $text, 'error' => null];
}

function extractTextFromPdf(string $filePath): array
{
    // Check if the pdftotext binary exists on the server (poppler-utils / xpdf-tools).
    $pdftotext = trim((string) shell_exec('which pdftotext 2>/dev/null'));

    if ($pdftotext !== '') {
        $outputFile = $filePath . '.txt';
        $safePath = escapeshellarg($filePath);
        $safeOut  = escapeshellarg($outputFile);
        shell_exec("pdftotext $safePath $safeOut 2>&1");

        if (file_exists($outputFile)) {
            $text = file_get_contents($outputFile);
            @unlink($outputFile);
            return ['success' => true, 'text' => $text, 'error' => null];
        }
    }

    return [
        'success' => false,
        'text'    => null,
        'error'   => 'PDF text extraction requires "pdftotext" (Poppler/Xpdf) installed on the server, ' .
                     'which was not found. Please install it, or paste the lesson note text directly instead.',
    ];
}
