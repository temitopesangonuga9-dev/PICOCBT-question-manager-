<?php
/**
 * PICOCBT Question Manager - General Helper Functions
 */

function e(string $str): string
{
    return htmlspecialchars($str, ENT_QUOTES, 'UTF-8');
}

/** Generate & store a CSRF token for the current session */
function csrfToken(): string
{
    if (empty($_SESSION['csrf_token'])) {
        $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
    }
    return $_SESSION['csrf_token'];
}

/** Verify a submitted CSRF token */
function verifyCsrf(?string $token): bool
{
    return $token !== null && !empty($_SESSION['csrf_token']) && hash_equals($_SESSION['csrf_token'], $token);
}

/** Flash message helper (stored in session, shown once) */
function setFlash(string $type, string $message): void
{
    $_SESSION['flash'] = ['type' => $type, 'message' => $message];
}

function getFlash(): ?array
{
    if (!empty($_SESSION['flash'])) {
        $flash = $_SESSION['flash'];
        unset($_SESSION['flash']);
        return $flash;
    }
    return null;
}

/**
 * List of the ten secondary school subjects used across PICOCBT.
 * Edit this list if your school's subject set differs.
 */
function subjectList(): array
{
    return [
        'Mathematics', 'English Language', 'Basic Science', 'Basic Technology',
        'Social Studies', 'Civic Education', 'Agricultural Science',
        'Business Studies', 'Computer Studies', 'French',
    ];
}

/**
 * Streams a set of questions (with options) as a CSV file matching the
 * import format expected by PICOCBT's admin/question_bank.php importer.
 *
 * Columns: subject, class_level, question_type, question_text,
 *          option_a, option_b, option_c, option_d, correct_option, theory_answer, difficulty
 */
function streamQuestionsAsCsv(array $questions, string $filename): void
{
    header('Content-Type: text/csv; charset=utf-8');
    header('Content-Disposition: attachment; filename="' . $filename . '"');

    $out = fopen('php://output', 'w');
    fputcsv($out, [
        'subject', 'class_level', 'question_type', 'question_text',
        'option_a', 'option_b', 'option_c', 'option_d',
        'correct_option', 'theory_answer', 'difficulty',
    ]);

    foreach ($questions as $q) {
        $opts = ['a' => '', 'b' => '', 'c' => '', 'd' => ''];
        $correct = '';
        if (!empty($q['options'])) {
            $letters = ['a', 'b', 'c', 'd'];
            foreach ($q['options'] as $i => $opt) {
                if (!isset($letters[$i])) break;
                $opts[$letters[$i]] = $opt['option_text'];
                if (!empty($opt['is_correct'])) {
                    $correct = $letters[$i];
                }
            }
        }

        fputcsv($out, [
            $q['subject'] ?? '',
            $q['class_level'] ?? '',
            $q['question_type'] ?? 'mcq',
            $q['question_text'] ?? '',
            $opts['a'], $opts['b'], $opts['c'], $opts['d'],
            $correct,
            $q['theory_answer'] ?? '',
            $q['difficulty'] ?? 'medium',
        ]);
    }

    fclose($out);
    exit;
}
